import { Controller } from '@nestjs/common';

@Controller('roles')
export class RolesController {}
