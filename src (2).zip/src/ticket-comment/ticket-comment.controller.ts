import { Controller } from '@nestjs/common';

@Controller('ticket-comment')
export class TicketCommentController {}
