import { Controller } from '@nestjs/common';

@Controller('status-log')
export class StatusLogController {}
